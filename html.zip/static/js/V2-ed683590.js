import{_ as e,o as c,d as n}from"./index-92f1be0d.js";const o={};function r(t,s){return c(),n("h1",null,"\u6211\u662FV2")}const a=e(o,[["render",r]]);export{a as default};
